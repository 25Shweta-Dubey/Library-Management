from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class homes(models.Model):
  

    Name= models.CharField(max_length=122)
    Email= models.CharField(max_length=122)
    # phone= models.CharField(max_length=122)
    Password=models.CharField(max_length=122)
    Book=models.CharField(max_length=122)
    Date=models.DateField()
    

        
class contact(models.Model):
  
  
    Name= models.CharField(max_length=122)
    Email=models.EmailField()
    Phone= models.CharField(max_length=122)
   
    Address=models.CharField(max_length=122)
  
   
    
  # one to many  
class ServiceReview(models.Model):
    Book= models.ForeignKey(homes, on_delete=models.CASCADE, related_name='Reviews')   
    user = models.ForeignKey(User, on_delete=models.CASCADE )
    rating=models.IntegerField()
    comment=models.TextField()
    date=models.DateTimeField()
    
    def __str__(self):
        return f'{self.user.username} reviews for{self.homes.Name}'
    
class Profile(models.Model):
    user= models.OneToOneField(User, on_delete=models.CASCADE) 
 


    def __str__(self):
        return self.user.username   
    
 