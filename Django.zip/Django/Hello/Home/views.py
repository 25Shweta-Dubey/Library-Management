from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth import authenticate, login


from datetime import datetime
from Home.models import homes
from Home.models import contact, Profile
from .forms import SignUpForm
# from django.db.models.signals import post_save
# from django.dispatch import receiver
from django.shortcuts import render, redirect, get_object_or_404
from .models import contact


def update_contact(request):
    if request.method == "POST":
        # Fetch the contact record using a unique identifier (e.g., Email)
        email = request.POST.get('email')
        contact_instance = get_object_or_404(contact, Email=email)

        # Update fields with the posted data
        contact_instance.Name = request.POST.get('name')
        contact_instance.Phone = request.POST.get('phone')
        contact_instance.Address = request.POST.get('address')
        contact_instance.save()  # Save updated contact to the database

        return redirect('home')

    # Render an update form
    return render(request, 'update_contact.html')


def update_home(request):
    if request.method== "POST" :
        
      # Fetch the contact record using a unique identifier (e.g., Email)
      email = request.POST.get('email')   
      home_instance = get_object_or_404(homes, Email=email)
      home_instance. Name= request.POST.get('name')
      home_instance.Email= request.POST.get('email')
      home_instance.Password= request.POST.get('password')
      home_instance.Book= request.POST.get('book')
      home_instance.Date= request.POST.get('date')
      
      home_instance.save() #save in the database...
    return render(request, 'update_home.html')  
      
# Create your views here.
def home(request):
 if request.method == "POST":
        Name= request.POST.get('name')
        Email= request.POST.get('email')
        Password= request.POST.get('password')
        Book= request.POST.get('book')
        Date= request.POST.get('date')
        new_home= homes(Name=Name, Email=Email, Password=Password,Book=Book,Date=datetime.today())
        new_home.save() #save in the database...

 return render(request, 'home.html')
    

      
 
def Contact(request):
      if request.method == "POST":
        Name= request.POST.get('name')
        Email= request.POST.get('email')
        Phone= request.POST.get('phone')
        Address= request.POST.get('address')
        
        new_contact= contact(Name=Name, Email=Email, Phone=Phone,Address=Address)
        new_contact.save() #save in the database...
     
        return redirect('home')
        
  
      return render(request, 'Contact.html')
 


#newly added function
def update_user_data(user):
    Profile.objects.update_or_create(user=user)   


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.refresh_from_db()  
            #newly added to add profile after signing up
            user.Profile=form.cleaned_data
            update_user_data(user)  
            # load the profile instance created by the signal
            user.save()
            raw_password = form.cleaned_data.get('password1')

            # login user after signing up
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)


            # redirect user to home page
            return redirect('Contact')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})




def index(request):
     
     return render(request, 'index.html')
   
def dashboard(request):
     
     return render(request, 'dashboard.html')



 

