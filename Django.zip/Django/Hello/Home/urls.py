from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from Home import views
from Home.views import  update_contact, update_home


urlpatterns = [
    # path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('home', views.home, name='home'),
    # path('Reg/', views.Reg, name='Reg'),
    path('Contact', views.Contact, name='Contact'),
    path('signup/', views.signup, name='signup'),
    path('update_contact/', views.update_contact, name='update_contact'),
    path('update_home/', views.update_home, name='update_home'),

    # path('login/', views.login, name='login'),
   
    #  path('logout/', views.logout, name='logout'),
    
   
]
