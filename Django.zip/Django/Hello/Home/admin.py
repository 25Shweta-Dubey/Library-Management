from django.contrib import admin
from Home.models import homes, ServiceReview, contact, Profile

# Register your models here.
class ServiceReviewInline(admin.TabularInline):
    model = ServiceReview
    extra=1

class homesAdmin(admin.ModelAdmin):
    list_display=('Name', 'Email', 'Book', 'Password', 'Date')  
    inlines =[ServiceReviewInline] 
    
admin.site.register(homes, homesAdmin)
admin.site.register(contact)
admin.site.register(Profile)





